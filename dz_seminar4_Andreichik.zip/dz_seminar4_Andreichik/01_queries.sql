SET search_path TO bookings, public;

-- Задача 1.1. Выполненные рейсы из московских аэропортов за август 2017
SELECT f.flight_no, dep.airport_name ->> 'en' AS departure_airport, f.actual_departure
FROM flights f
JOIN airports_data dep ON dep.airport_code = f.departure_airport
WHERE f.status = 'Arrived'
  AND dep.city ->> 'en' = 'Moscow'
  AND f.actual_departure >= TIMESTAMPTZ '2017-08-01 00:00:00+03'
  AND f.actual_departure <  TIMESTAMPTZ '2017-09-01 00:00:00+03'
ORDER BY f.actual_departure ASC;

-- Задача 1.2. Прибытия с опозданием более 2 часов
SELECT flight_no, scheduled_arrival, actual_arrival,
       ROUND((EXTRACT(EPOCH FROM (actual_arrival - scheduled_arrival)) / 60.0)::numeric, 2) AS delay_minutes
FROM flights
WHERE status = 'Arrived'
  AND actual_arrival IS NOT NULL
  AND actual_arrival > scheduled_arrival + INTERVAL '2 hours'
ORDER BY delay_minutes DESC;

-- Задача 1.3. Число выполненных рейсов для номеров PG04xx
SELECT flight_no, COUNT(*) AS flights_count
FROM flights
WHERE status = 'Arrived'
  AND flight_no LIKE 'PG04%'
GROUP BY flight_no
ORDER BY flight_no;

-- Задача 2.1. Число рейсов и среднее опоздание прибытия по аэропорту вылета.
-- COUNT(*) считает все рейсы аэропорта; AVG игнорирует NULL actual_arrival.
SELECT f.departure_airport,
       COUNT(*) AS flights_count,
       ROUND(AVG(EXTRACT(EPOCH FROM (f.actual_arrival - f.scheduled_arrival)) / 60.0)::numeric, 2)
         AS avg_arrival_delay_minutes
FROM flights f
GROUP BY f.departure_airport
HAVING COUNT(*) > 500
ORDER BY avg_arrival_delay_minutes DESC NULLS LAST;

-- Задача 3.1. Топ-10 самых дорогих проданных сегментов билетов
SELECT t.passenger_name, tf.amount, f.flight_no,
       dep.city ->> 'en' AS departure_city,
       arr.city ->> 'en' AS arrival_city
FROM ticket_flights tf
JOIN tickets t ON t.ticket_no = tf.ticket_no
JOIN flights f ON f.flight_id = tf.flight_id
JOIN airports_data dep ON dep.airport_code = f.departure_airport
JOIN airports_data arr ON arr.airport_code = f.arrival_airport
ORDER BY tf.amount DESC
LIMIT 10;

-- Задача 3.2. Все аэропорты, включая аэропорты без вылетающих рейсов
SELECT a.airport_code, a.airport_name ->> 'en' AS airport_name,
       COUNT(f.flight_id) AS departing_flights
FROM airports_data a
LEFT JOIN flights f ON f.departure_airport = a.airport_code
GROUP BY a.airport_code, a.airport_name
ORDER BY departing_flights DESC, a.airport_code;

-- Задача 3.3. Топ-5 пассажиров по суммарным тратам
SELECT t.passenger_id, t.passenger_name,
       COUNT(DISTINCT tf.flight_id) AS flight_count,
       SUM(tf.amount) AS total_spent
FROM tickets t
JOIN ticket_flights tf ON tf.ticket_no = t.ticket_no
GROUP BY t.passenger_id, t.passenger_name
ORDER BY total_spent DESC
LIMIT 5;
