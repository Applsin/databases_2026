SET search_path TO bookings, public;

-- Неоптимизированный вариант: функция применяется к столбцу даты.
-- DOW: 0=воскресенье, 6=суббота. Важно: этот запрос выбирает выходные
-- августа по фактическому времени вылета.
EXPLAIN (ANALYZE, BUFFERS)
SELECT flight_id, flight_no, actual_departure
FROM flights
WHERE status = 'Arrived'
  AND actual_departure >= TIMESTAMP '2017-08-01'
  AND actual_departure < TIMESTAMP '2017-09-01'
  AND EXTRACT(DOW FROM actual_departure) IN (0, 6)
ORDER BY actual_departure;

-- Оптимизированный вариант: диапазоны выходных, без функции над столбцом.
-- Даты суббот и воскресений августа 2017: 5-6, 12-13, 19-20, 26-27.
EXPLAIN (ANALYZE, BUFFERS)
SELECT flight_id, flight_no, actual_departure
FROM flights
WHERE status = 'Arrived'
  AND (
    (actual_departure >= TIMESTAMP '2017-08-05' AND actual_departure < TIMESTAMP '2017-08-07')
    OR (actual_departure >= TIMESTAMP '2017-08-12' AND actual_departure < TIMESTAMP '2017-08-14')
    OR (actual_departure >= TIMESTAMP '2017-08-19' AND actual_departure < TIMESTAMP '2017-08-21')
    OR (actual_departure >= TIMESTAMP '2017-08-26' AND actual_departure < TIMESTAMP '2017-08-28')
  )
ORDER BY actual_departure;
