SET search_path TO bookings, public;

-- Помесячная выручка за 2017 год и общий итог через ROLLUP.
-- GROUPING(month_start)=1 отмечает итоговую строку (NULL создан ROLLUP),
-- поэтому условие HAVING сохраняет её независимо от месячной выручки.
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
  CASE WHEN GROUPING(date_trunc('month', b.book_date)) = 1
       THEN 'ИТОГО'
       ELSE TO_CHAR(date_trunc('month', b.book_date), 'YYYY-MM')
  END AS month,
  SUM(tf.amount) AS revenue
FROM bookings b
JOIN tickets t ON t.book_ref = b.book_ref
JOIN ticket_flights tf ON tf.ticket_no = t.ticket_no
WHERE b.book_date >= TIMESTAMP '2017-01-01'
  AND b.book_date <  TIMESTAMP '2018-01-01'
GROUP BY ROLLUP (date_trunc('month', b.book_date))
HAVING GROUPING(date_trunc('month', b.book_date)) = 1
    OR SUM(tf.amount) > 10000000000
ORDER BY GROUPING(date_trunc('month', b.book_date)), date_trunc('month', b.book_date);
