SET search_path TO bookings, public;

-- Правильный вариант: статус в ON сохраняет аэропорты без прибывших рейсов.
SELECT a.airport_code, a.airport_name ->> 'en' AS airport_name,
       COUNT(f.flight_id) AS arrived_flights
FROM airports_data a
LEFT JOIN flights f
  ON f.arrival_airport = a.airport_code
 AND f.status = 'Arrived'
GROUP BY a.airport_code, a.airport_name
ORDER BY arrived_flights DESC, a.airport_code;

EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT a.airport_code, a.airport_name ->> 'en' AS airport_name,
       COUNT(f.flight_id) AS arrived_flights
FROM airports_data a
LEFT JOIN flights f
  ON f.arrival_airport = a.airport_code
 AND f.status = 'Arrived'
GROUP BY a.airport_code, a.airport_name
ORDER BY arrived_flights DESC, a.airport_code;

-- Контрольный ошибочный вариант: WHERE отбрасывает строки NULL-расширения,
-- поэтому фактически исчезают аэропорты без Arrived.
SELECT a.airport_code, a.airport_name ->> 'en' AS airport_name,
       COUNT(f.flight_id) AS arrived_flights
FROM airports_data a
LEFT JOIN flights f ON f.arrival_airport = a.airport_code
WHERE f.status = 'Arrived'
GROUP BY a.airport_code, a.airport_name
ORDER BY arrived_flights DESC, a.airport_code;

EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT a.airport_code, a.airport_name ->> 'en' AS airport_name,
       COUNT(f.flight_id) AS arrived_flights
FROM airports_data a
LEFT JOIN flights f ON f.arrival_airport = a.airport_code
WHERE f.status = 'Arrived'
GROUP BY a.airport_code, a.airport_name
ORDER BY arrived_flights DESC, a.airport_code;

-- Почему COUNT(*) неверен: при отсутствии совпадения LEFT JOIN всё равно
-- создаёт одну строку аэропорта с NULL-полями flights, и COUNT(*) даст 1.
-- COUNT(f.flight_id) не считает NULL и даст 0.
