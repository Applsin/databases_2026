SET search_path TO bookings, public;

-- NOT IN: обычно возвращает корректный результат, если подзапрос не содержит NULL.
-- Если ticket_flights.flight_id может быть NULL, NOT IN может вернуть 0 строк.
EXPLAIN (ANALYZE, BUFFERS)
SELECT f.flight_id, f.flight_no
FROM flights f
WHERE f.flight_id NOT IN (
  SELECT tf.flight_id
  FROM ticket_flights tf
  WHERE tf.fare_conditions = 'Business'
);

-- NOT EXISTS: NULL-устойчивое отрицание существования совпадения.
EXPLAIN (ANALYZE, BUFFERS)
SELECT f.flight_id, f.flight_no
FROM flights f
WHERE NOT EXISTS (
  SELECT 1
  FROM ticket_flights tf
  WHERE tf.flight_id = f.flight_id
    AND tf.fare_conditions = 'Business'
);
