SET search_path TO bookings, public;

-- Шаг 1: план ДО индекса
EXPLAIN (ANALYZE, BUFFERS)
SELECT status, COUNT(*)
FROM flights
GROUP BY status;

-- Шаг 2: создать покрывающий для status индекс
CREATE INDEX IF NOT EXISTS idx_flights_status ON flights(status);

-- Visibility Map актуализируется VACUUM. VACUUM нельзя запускать внутри явной транзакции.
VACUUM (ANALYZE) flights;

-- Шаг 3: план ПОСЛЕ индекса
EXPLAIN (ANALYZE, BUFFERS)
SELECT status, COUNT(*)
FROM flights
GROUP BY status;

